ضع ملفاتك هنا بهذه الأسماء بالضبط (حروف صغيرة):

assets/kingdom.webp           ← خلفية المملكة (أو png / jpg)
assets/heroes/<الاسم>.webp    ← صورة البطل (أو png / jpg)
assets/video/<الاسم>.mp4      ← فيديو عرض البطل

أسماء الأبطال:
bella  korin  sami  raiko  luna  dracu
titan  jinn   marina outa  maro  areej

مثال: assets/heroes/maro.webp  و  assets/video/maro.mp4
